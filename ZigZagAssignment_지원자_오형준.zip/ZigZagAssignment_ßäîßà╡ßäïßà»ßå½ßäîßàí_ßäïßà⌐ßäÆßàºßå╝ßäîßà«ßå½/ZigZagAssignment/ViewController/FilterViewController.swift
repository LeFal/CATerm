//
//  FilterViewController.swift
//  ZigZagAssignment
//
//  Created by LEOFALCON on 2017. 11. 30..
//  Copyright © 2017년 LeFal. All rights reserved.
//

import UIKit

class FilterViewController: UIViewController {

    @IBOutlet var ageButtonCollection: [UIButton]!
    @IBOutlet var styleButtonCollection: [UIButton]!
    private var ageFilterArray = [Int]()
    private var styleFilterSet = Set<String>()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        ageFilterArray = ShopStore.shared.ageFilterArray
        styleFilterSet = ShopStore.shared.styleFilterSet
        setSelectedAgeButton(array: ageFilterArray)
        setSelectedStyleButton(set: styleFilterSet)
        setButtonLayout()
    }   

    // change ageFilterArray, styleFilterSet value to filter
    @IBAction func toggleAgeFilter(_ sender: UIButton) {
        sender.isSelected = sender.isSelected ? false : true
        ageFilterArray[sender.tag] = sender.isSelected ? 1 : 0
    }
    
    @IBAction func toggleStyleFilter(_ sender: UIButton) {
        sender.isSelected = sender.isSelected ? false : true
        if sender.isSelected {
            styleFilterSet.insert((sender.titleLabel?.text)!)
        } else {
            styleFilterSet.remove((sender.titleLabel?.text)!)
        }
    }
    
    @IBAction func close(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func initailize(_ sender: Any) {
        for btn in ageButtonCollection {
            btn.isSelected = false
        }
        for btn in styleButtonCollection {
            btn.isSelected = false
        }
        ageFilterArray = [0,0,0,0,0,0,0]
        styleFilterSet.removeAll()
    }
    
    @IBAction func done(_ sender: Any) {
        // change singleton value (after change data, ShopStore filter and sort shops)
        ShopStore.shared.ageFilterArray = ageFilterArray
        ShopStore.shared.styleFilterSet = styleFilterSet
        self.dismiss(animated: true, completion: nil)
    }
    
    func setSelectedAgeButton(array: [Int]) {
        var i = 0
        for num in array {
            if num == 1 {
                self.ageButtonCollection[i].isSelected = true
            } else {
                self.ageButtonCollection[i].isSelected = false
            }
            i += 1
        }
    }
    
    func setSelectedStyleButton(set: Set<String>) {
        for btn in styleButtonCollection {
            if set.contains((btn.titleLabel?.text)!) {
                btn.isSelected = true
            }
        }
    }
    
    // set Buttons Layout
    func setButtonLayout() {
        for btn in ageButtonCollection {
            btn.setBackgroundColor(color: btn.tintColor, forState: .selected)
            btn.setTitleColor(.white, for: .selected)
            btn.layer.masksToBounds = true
            btn.layer.cornerRadius = 10
        }
        for btn in styleButtonCollection {
            btn.setBackgroundColor(color: btn.tintColor, forState: .selected)
            btn.setTitleColor(.white, for: .selected)
            btn.layer.masksToBounds = true
            btn.layer.cornerRadius = 10
        }
        
    }
}

