//
//  ShopListTableViewCell.swift
//  ZigZagAssignment
//
//  Created by LEOFALCON on 2017. 11. 30..
//  Copyright © 2017년 LeFal. All rights reserved.
//

import UIKit
import Kingfisher

class ShopListTableViewCell: UITableViewCell {
    @IBOutlet var shopImageView: UIImageView!
    @IBOutlet var shopName: UILabel!
    @IBOutlet var rank: UILabel!
    @IBOutlet var age: UILabel!
    @IBOutlet var style1: UILabel!
    @IBOutlet var style2: UILabel!
    
    func initCell(url: URL, name: String, rank: Int, age: [Int], style: String) {
        setImage(with: url)
        styleLabelLayout(string: style)
        self.shopName.text = name
        self.rank.text = "\(rank)"
        self.age.text = setAgeLabel(array: age)
        
    }
    
    // draw Image with kingfisher
    private func setImage(with url: URL)  {
        let mainDomain = getMainDomainString(from: url.host!)
        let imageURL = URL(string:"https://cf.shop.s.zigzag.kr/images/\(mainDomain).jpg")!
        self.shopImageView.kf.setImage(with: imageURL)
        self.shopImageView.layer.masksToBounds = true
        self.shopImageView.layer.cornerRadius = shopImageView.frame.width/2
    }
    
    // extract main domain
    private func getMainDomainString(from url: String) -> String {
        let urlArray = url.components(separatedBy: ".")
        if urlArray[0] == "www" {
            return urlArray[1]
        }
        return urlArray[0]
    }
    
    // draw age
    private func setAgeLabel(array: [Int]) -> String {
        var resultString = ""
        let teen: Bool = array[0] == 1 ? true : false
        let twenties: Bool = array[1] == 1 || array[2] == 1 || array[3] == 1  ? true : false
        let thirties: Bool = array[4] == 1 || array[5] == 1 || array[6] == 1  ? true : false

        if teen && twenties && thirties {
            return "모두"
        }
        if teen { resultString += "10대 " }
        if twenties { resultString += "20대 " }
        if thirties { resultString += "30대" }
        
        if resultString.last == " " {
            resultString.removeLast()
        }

        return resultString
    }
    
    private func ageLabelLayout() {
        self.age.layer.borderColor = UIColor.darkGray.cgColor
        self.age.layer.borderWidth = 1
        self.age.layer.cornerRadius = 5
        self.age.layer.masksToBounds = true
    }
    
    // draw style label
    private func styleLabelLayout(string: String) {
        let styleArray = string.components(separatedBy: ",")
        self.style1.text = styleArray[0]
        if styleArray.count == 1 {
            self.style2.isHidden = true
        } else {
            self.style2.text = styleArray[1]
        }
    }
    

}
