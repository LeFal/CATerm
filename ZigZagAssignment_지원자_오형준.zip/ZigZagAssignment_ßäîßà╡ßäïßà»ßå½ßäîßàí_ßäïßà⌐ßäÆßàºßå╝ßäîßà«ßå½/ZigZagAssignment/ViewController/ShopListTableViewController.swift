//
//  ViewController.swift
//  ZigZagAssignment
//
//  Created by LEOFALCON on 2017. 11. 29..
//  Copyright © 2017년 LeFal. All rights reserved.
//

import UIKit

class ShopListTableViewController: UIViewController{
    
    @IBOutlet var weekTitle: UILabel!
    @IBOutlet var shopListTableView: UITableView!
    var filterAgeArray = [0,0,0,0,0,0]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        fetchShopingList()
        weekTitle.text = ShopStore.shared.allShopList.week
        shopListTableView.delegate = self
        shopListTableView.dataSource = self
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.shopListTableView.reloadData()
    }
    
    func fetchShopingList()  {
        JsonManager.getJSONFromURL("shop_list") { (data, error) in
            do {
                let decoded = try JSONDecoder().decode(ShopList.self, from: data!)
                ShopStore.shared.allShopList = decoded
                ShopStore.shared.filterdShopList = ShopStore.shared.allShopList.list
                ShopStore.shared.filterdShopList.sort{$0.score > $1.score}
                self.shopListTableView.reloadData()
            } catch {
                print(error)
            }
        }
    }
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }

}

extension ShopListTableViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 75
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return ShopStore.shared.filterdShopList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell  = tableView.dequeueReusableCell(withIdentifier: "ShopCell", for: indexPath) as! ShopListTableViewCell
        
        let shop = ShopStore.shared.filterdShopList[indexPath.row]
        cell.initCell(url: shop.url, name: shop.name, rank: indexPath.row + 1, age: shop.age, style: shop.style)
        
        return cell
    }
}
