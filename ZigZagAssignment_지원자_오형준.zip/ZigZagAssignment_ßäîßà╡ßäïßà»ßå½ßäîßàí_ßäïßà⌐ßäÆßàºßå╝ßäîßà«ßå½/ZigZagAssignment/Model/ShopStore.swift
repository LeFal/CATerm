//
//  ShopStore.swift
//  ZigZagAssignment
//
//  Created by LEOFALCON on 2017. 12. 1..
//  Copyright © 2017년 LeFal. All rights reserved.
//

import Foundation

class ShopStore {
    // Singleton
    static let shared = ShopStore()
    
    var allShopList: ShopList!
    var filterdShopList = [Shop]()
    
    var ageFilterArray = [0,0,0,0,0,0,0]
    var styleFilterSet = Set<String>() {
        didSet {
            agefilter()
            styleFilter()
        }
    }
    
   private func agefilter() {
        // When ageFilterArray in singlton is changed filter array
        let filterdShop = self.allShopList.list.filter { (shop) -> Bool in
            // if there is no selection, Show all
            if ageFilterArray == [0,0,0,0,0,0,0] {
                return true
            }
            // filter with age by array
            for i in 0...self.ageFilterArray.count - 1 {
                if self.ageFilterArray[i] == 1 && shop.age[i] == 1 { return true }
            }
            return false
        }
        self.filterdShopList = filterdShop.sorted{$0.score > $1.score}
    }
    
    private func styleFilter()  {
        if self.styleFilterSet.isEmpty {
            return
        }
        
        let twoStyleMatchfilterdShop = self.filterdShopList.filter({ (shop) -> Bool in
            var shopStyles = shop.style.components(separatedBy: ",")
            shopStyles.append("") // To avoid out of index error
            // Filter the two match
            if styleFilterSet.contains(shopStyles[0]) && styleFilterSet.contains(shopStyles[1]) {
                return true
            } else {
                return false
            }
        })
        
        let oneStyleMatchFilterdShop = self.filterdShopList.filter({ (shop) -> Bool in
            var count = 0
            var shopStyles = shop.style.components(separatedBy: ",")
            shopStyles.append("") // To avoid out of index error
            count += styleFilterSet.contains(shopStyles[0]) ? 1 : 0
            count += styleFilterSet.contains(shopStyles[1]) ? 1 : 0
            // Filter the one match
            if count == 1 {
                return true
            } else {
                return false
            }
        })
        
        self.filterdShopList = twoStyleMatchfilterdShop.sorted{ $0.score > $1.score}
        self.filterdShopList += oneStyleMatchFilterdShop.sorted{ $0.score > $1.score}
        
    }
}
