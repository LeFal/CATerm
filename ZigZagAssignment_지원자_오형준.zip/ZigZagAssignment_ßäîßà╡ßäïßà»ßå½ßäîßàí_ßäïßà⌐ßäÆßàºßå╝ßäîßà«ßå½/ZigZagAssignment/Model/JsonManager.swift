//
//  DataManager.swift
//  ZigZagAssignment
//
//  Created by LEOFALCON on 2017. 11. 29..
//  Copyright © 2017년 LeFal. All rights reserved.
//

import Foundation

class JsonManager {
    public static func getJSONFromURL(_ resource:String, completion:@escaping (_ data:Data?, _ error:Error?) -> Void) {
        let filePath = Bundle.main.path(forResource: resource, ofType: "json")
        let url = URL(fileURLWithPath: filePath!)
        let data = try! Data(contentsOf: url, options: .uncached)
        completion(data, nil)
    }
}
