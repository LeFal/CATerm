//
//  ShopModel.swift
//  ZigZagAssignment
//
//  Created by LEOFALCON on 2017. 11. 29..
//  Copyright © 2017년 LeFal. All rights reserved.
//

import Foundation

struct ShopList: Codable {
    let week: String
    let list: [Shop]
}

struct Shop: Codable {
    let name: String
    let style: String
    let age: [Int]
    let score: Int
    let url: URL
    
    private enum CodingKeys : String, CodingKey {
        case name = "n", style = "S", age = "A", score = "0", url = "u"
    }
}


